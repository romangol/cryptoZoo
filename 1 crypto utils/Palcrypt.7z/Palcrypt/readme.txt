-------------------------------------------------------------------------------------------
Palcrypt 3.0.0.1 is distributed under the GNU General Public License by Machinescript, Inc.
-------------------------------------------------------------------------------------------


-------------------------------------------------------------------------------------------
Welcome to Palcrypt, a file encryption program for Microsoft Windows...
-------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
Palcrypt uses the AES 128-bit key encryption algorithm to encrypt-
decrypt files. MD5, SHA1 & Blowfish are also used for even stronger encryption.
RC4 algorithm is also supported for program-internal use.
-------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
Easy to use. Just right-click the file to encrypt from the explorer &
double-click to decrypt. Please note that in case you forget your
password there's nothing you (or we at Machinescipt) can do to
retrieve your data.
-------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
Technical details about the AES 128 bit encryption algorithm:
-Files are processed in place (effectively wiping the original). 
-It uses 8 round AES in ciphertext feedback mode. 
-The initalisation vector (IV) is set to zeros. 
-The feedback is done on 8 byte blocks. 
-The AES key is the user key followed by '\r' and filled with zeros. 
-It is optimised for size, not speed.
-------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
Remember to visit the Palcrypt website at http://www.machinescript.com
for the latest version, information and support.
-------------------------------------------------------------------------------------------